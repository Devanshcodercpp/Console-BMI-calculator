This program will require you to have atleast a windows 10 or above and also x64 bit because i have only created a x64 debug and .exe file.
